﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ConnectSQL.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace ConnectSQL.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePerson.xaml
    /// </summary>
    public partial class PagePerson : Page
    {
        List<Person> printItems;
        public PagePerson()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = TestEntities.GetContext().Person.ToList();
            // Получение списка
            printItems = TestEntities.GetContext().Person.ToList();
            CMBFilterGroup.ItemsSource = TestEntities.GetContext().Group.ToList();
            CMBFilterGroup.SelectedValuePath = "IDGroup";
            CMBFilterGroup.DisplayMemberPath = "NameGroup";
        }

        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddStudent((Person)DtgSQL.SelectedItem));
            // Classes.ClassFrame.frmObj.Navigate(new AddStudent((sender as Button).DataContext as Person));

        }

        private void BTNadd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddStudent(null));
        }

        private void BTNdel_Click(object sender, RoutedEventArgs e)
        {
           var personsForRemoving = DtgSQL.SelectedItems.Cast<Person>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {personsForRemoving.Count()} записи?","Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    TestEntities.GetContext().Person.RemoveRange(personsForRemoving);
                    TestEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQL.ItemsSource = TestEntities.GetContext().Person.ToList();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                TestEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DtgSQL.ItemsSource = TestEntities.GetContext().Person.ToList();
            }
        }

        private void CMBFilterGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int IDGroup = CMBFilterGroup.SelectedIndex + 1;
            DtgSQL.ItemsSource = TestEntities.GetContext().Person.Where(x => x.IDGroup == IDGroup).ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CMBFilterGroup.SelectedItem = null;
            DtgSQL.ItemsSource = TestEntities.GetContext().Person.ToList();
        }

        private void BTNPrint_Click(object sender, RoutedEventArgs e)
        {
            // Объект Excel
            var app = new Excel.Application();
            
            // Книга
            Excel.Workbook wb = app.Workbooks.Add();
            
            // Лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];

            // Ячейка
            int IndexRows = 1;
            worksheet.Cells[1][IndexRows] = "Номер"; // 1) номер столбца, 2) номер строки
            worksheet.Cells[2][IndexRows] = "Имя";
            worksheet.Cells[3][IndexRows] = "Фамилия";
            worksheet.Cells[4][IndexRows] = "Возраст";
            worksheet.Cells[5][IndexRows] = "Группа";
            var printItems = TestEntities.GetContext().Person.ToList();
            //цикл по данным из таблицы
            foreach (var item in printItems)
            {
                worksheet.Cells[1][IndexRows + 1] = IndexRows;
                worksheet.Cells[2][IndexRows + 1] = item.FirstName;
                worksheet.Cells[3][IndexRows + 1] = item.LastName;
                worksheet.Cells[4][IndexRows + 1] = item.Age;
                worksheet.Cells[5][IndexRows + 1] = item.Group.NameGroup;
                IndexRows++;
            }
            // Показать Excel
            app.Visible = true;
        }
    }
}
